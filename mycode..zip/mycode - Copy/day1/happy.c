#include <stdio.h>

int main() {
  int n, sum, digit;
  printf("Enter a number: ");
  scanf("%d", &n);
  sum = n;
  while (sum != 1 && sum != 4) {
    int temp = sum;
    sum = 0;
    while (temp > 0) {
      digit = temp % 10;
      sum += digit * digit;
      temp /= 10;
    }
  }
  if (sum == 1) {
    printf("%d is a happy number.\n", n);
  } else {
    printf("%d is not a happy number.\n", n);
  }
  return 0;
}